# React Odontogram

React Odontogram is a control to manage odontograms in dental clinics build with React.